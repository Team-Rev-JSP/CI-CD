import React from 'react';
import { SolvequesForm } from '../Solveques/SolvequesForm' 

export function Solveques (props) {
    return (
        <>
            <SolvequesForm/>
        </>
    );
};