import React from 'react';

export function Vulnerable (props) {
    return (
        <>
        </>
    );
};