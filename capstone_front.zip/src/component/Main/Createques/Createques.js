import React from 'react';

export function Createques (props) {
    return (
        <>
        </>
    );
};