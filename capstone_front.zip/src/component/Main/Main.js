import React from 'react'
import './main.css'

export function Main(props) {

    return (
        <div>
        
        </div>
    );
}