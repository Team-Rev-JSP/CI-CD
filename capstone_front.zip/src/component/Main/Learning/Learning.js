import React from 'react';
import { LearningForm } from '../Learning/LearningForm' 

export function Learning(props) {
    return (
        <>
            <LearningForm/>
        </>
    );
};